import json

def lambda_handler(event, context):
  print('Event -')
  parsed_event = json.loads(event)
  print(json.dumps(parsed_event, indent=4, sort_keys=True))

  print('Context -')
  parsed_context = json.loads(context)
  print(json.dumps(parsed_context, indent=4, sort_keys=True))
  
  return 'pong'